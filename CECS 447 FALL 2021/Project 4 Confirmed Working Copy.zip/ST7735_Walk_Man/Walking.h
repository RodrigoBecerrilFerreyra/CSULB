// filename ******** fixed.h ************** 
// possible header file for Lab 1 
// feel free to change the specific syntax of your system
// put your name here
// put the date here


void ST7735_XYPlotMan(int32_t x, int32_t y,int32_t h, uint16_t color);



